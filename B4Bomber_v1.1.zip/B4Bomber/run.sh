#!/bin/bash
# Bash Menu m4u.yt --- sms & call bomber 
clear
bash .files/logo.sh
PS3='Please enter your choice: '
options=("sms bomber" "call bomber" "install" "update" "about me" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "sms bomber")
            bash .files/sms.sh
            ;;
        "call bomber")
            bash .files/call.sh
            ;;
        "install")
            bash .files/install.sh
            ;;
        "update")
            bash .files/update.sh
            ;;
         "about me")
            bash .files/about.sh
            ;;
        "Quit")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done
