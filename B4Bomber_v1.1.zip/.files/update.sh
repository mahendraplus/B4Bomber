clear
for ((n=0;n<3;n++))
do
echo "  checking update."
sleep 1
clear
echo "  checking update.."
sleep 1
clear
echo "  checking update..."
sleep 1
clear
done
echo " Updated successfully"
sleep 2
bash run.sh