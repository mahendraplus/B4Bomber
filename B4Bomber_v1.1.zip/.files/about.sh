clear
xdg-open https://www.instagram.com/m4u.yt?r=nametag

bash run.sh