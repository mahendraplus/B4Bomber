#!/bin/bash
apt update
apt upgrade
apt install curl
clear
echo "  □□□□□0%"
sleep 2
clear
echo "  ■□□□□20%"
sleep 2
clear
echo "  ■■□□□40%"
sleep 2
clear
echo "  ■■■□□60%"
sleep 2
clear
echo "  ■■■■□80%"
sleep 2
clear
echo "  ■■■■□90%"
sleep 1
clear
echo "  ■■■■■100%"
sleep 1
echo "  Installed Successfully"
sleep 2
bash run.sh